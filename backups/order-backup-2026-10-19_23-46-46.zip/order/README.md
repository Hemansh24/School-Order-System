# School Book Order Operations Dashboard

Next.js App Router application for school-book order processing with the required Order Sheet 1 -> 2A or 2B1/2B2 -> 3 workflow.

## Stack

- Next.js App Router, React, TypeScript
- Tailwind CSS custom UI
- PostgreSQL with Prisma migrations
- Zod validation on the server and React Hook Form validation on the client
- Server Actions for order mutations

## Workflow Rules Implemented

- Each order uses one stable `order_no`; editing it before finalization never changes that number.
- Descriptive orders create only Order Sheet 2A rows.
- Ambiguous orders create only Order Sheet 2B1 school rows and 2B2 grouped item rows.
- Ambiguous quantities are not forced into school-wise allocations.
- Finalization creates Order Sheet 3 rows from either 2A or 2B2.
- Order Sheet 3 has its own `order_sheet_3_id`, plus `source_type` and `source_id`.
- Finalized orders are protected from direct edits.

## Setup

### Prerequisites

- Git
- Node.js 22 LTS and npm
- PostgreSQL with a running server
- Network access to Firebase project `system-order-34c0a`

### Fresh clone

1. Clone the repository and enter it:

```bash
git clone <repository-url>
cd order
```

2. Install the exact dependency versions from the lockfile:

```bash
npm ci
```

3. Create the PostgreSQL database:

```sql
CREATE DATABASE school_order_management;
```

4. Copy `.env.example` to `.env`. On Windows PowerShell:

```powershell
Copy-Item .env.example .env
```

Update `DATABASE_URL` in `.env` if the PostgreSQL username, password, host, port, or database name differs from the example.

5. Apply the committed database migrations:

```bash
npm run prisma:deploy
```

6. Import shared schools, vendors, and items from Firebase Data Connect:

```bash
npm run master-data:sync
```

The import order is significant: schools must exist before bookseller-school mappings are created. The import commands replace the local organisation, school, vendor, and item master tables. These Firebase imports require no Google Sheets credentials, but the GS refresh at the end of `master-data:sync` requires Google Sheets read access.

`schools:sync` always imports the shared Firebase/Data Connect organisations and their PT codes. Local Organisation records are not used for this shared master-data import, so they cannot prevent bookseller-to-school mappings from being created.

### Christian group master data

Christian C1 groups follow the same Firebase-first pattern as schools, vendors, and items. A trusted publisher environment reads the `Christian-Group Sheet` and writes its canonical copy to Firebase:

```bash
npm run christian-groups:publish
```

Configure `CHRISTIAN_GROUPS_SHEET_ID`, `CHRISTIAN_GROUPS_SHEET_RANGE`, and `GOOGLE_SHEETS_SERVICE_ACCOUNT_FILE` for a Google service account that has Viewer access to that sheet. Set `FIREBASE_ADMIN_SERVICE_ACCOUNT_FILE` as well when the publisher machine does not already have Firebase Application Default Credentials. Christian groups are read from local PostgreSQL and refreshed from Firebase through the **Sync Christian Groups** button.

### GS master data and membership

The Grouped Schools page reads GS groups, addresses, and member PR/PT codes from PostgreSQL. Membership uses the trimmed, case-insensitive `Organisation.groupCode` relationship. Common school names are retained in metadata only.

Preview or apply a direct Google Sheets import:

```bash
npx tsx scripts/import-gs-groups.ts
npx tsx scripts/import-gs-groups.ts --apply
```

Configure `GROUP_SHEETS_ID`, `GROUP_SHEETS_RANGE`, and `GOOGLE_SHEETS_SERVICE_ACCOUNT_FILE` as needed. Application Default Credentials must have the Sheets read scope if no service-account file is supplied. The website's **Refresh GS from Google Sheet** action uses the same importer. A credential error preserves the current local dataset.

An authenticated connector export can also be imported as a JSON array of rows, including the header:

```bash
npx tsx scripts/import-gs-groups.ts --file tmp/group-sheet-import.json
npx tsx scripts/import-gs-groups.ts --file tmp/group-sheet-import.json --apply
npx tsx scripts/verify-group-logic.ts
```

Imports preserve record IDs, retire absent GS masters, and save pre-import JSON snapshots under `tmp/group-backups/` (excluded from Git). Raw source columns are stored in group metadata. The approved local `GSO198` correction is applied when `GS0198` exists; correcting the source organisation record separately prevents an organisation refresh from restoring that typo.

GS combined orders include every member organisation, allocate PT codes to PR-only members when saved, and use one shared billing/shipping address. Multiple locations require an explicit choice. Saved participants and addresses remain snapshots. Reporting parents link independent member PT orders and preserve each child's destination and fulfillment; they cannot be finalized into fulfillment rows. Christian order behavior is unchanged.

7. Start the development server:

```bash
npm run dev
```

Open `http://localhost:3000`.

8. Verify the Organisations, Schools, Vendors, Items, Create Order, Orders, and Reports/Search pages. Create one test order to verify local PostgreSQL writes.

### Optional data workflows

To install demo schools, vendors, items, and orders instead of shared master data, run:

```bash
npm run prisma:seed
```

The seed command deletes existing application data before inserting demo records. Do not run it against a database containing data you need.

`npm run organisations:sync` is a separate Google Sheets-to-local-PostgreSQL import. It requires `GOOGLE_SHEETS_ID`, `GOOGLE_SHEETS_RANGE`, Google Application Default Credentials, and read access to the spreadsheet. It is not required for the normal Firebase Data Connect setup above.

The shared imports are also available through replace buttons on the Schools, Vendors, and Items pages. Each clone uses its own PostgreSQL database from `DATABASE_URL`; Git never transfers PostgreSQL contents or `.env` secrets.

### Production check

Before handing off a clone, verify a production build:

```bash
npm run build
npm start
```

## Important Files

- `prisma/schema.prisma` - database schema and enum/table mapping.
- `prisma/migrations/202605180001_init/migration.sql` - initial PostgreSQL migration.
- `lib/services/orders.ts` - reusable business logic for creation, locking, finalization, status, revision, and search.
- `lib/validation/orders.ts` - Zod validation for Sheet 1, 2A, 2B1, 2B2, and finalization fields.
- `components/orders/create-order-form.tsx` - step-based creation flow.
- `app/orders/[id]/page.tsx` - workflow-specific order details page.

## Authentication

The project includes a login-ready structure and a stub current user in `lib/auth.ts`. Replace this with NextAuth, custom sessions, or your preferred provider when real authentication is required.
